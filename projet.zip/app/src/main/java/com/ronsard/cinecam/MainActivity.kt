package com.ronsard.cinecam

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.ImageFormat
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.util.Range
import android.util.Size
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {

    private val S: Map<String, Map<String, String>> = mapOf(
        "fr" to mapOf(
            "switch" to "Changer de caméra", "lang" to "Langue : Français", "report" to "Rapport de l'appareil",
            "auto" to "Tout en automatique", "manExp" to "Exposition manuelle", "manFocus" to "Mise au point manuelle",
            "iso" to "ISO", "shutter" to "Vitesse", "focus" to "Mise au point",
            "noperm" to "Autorisation caméra refusée. Active-la dans les paramètres du téléphone.",
            "nocam" to "Aucune caméra trouvée", "err" to "Erreur caméra", "yes" to "Oui", "no" to "Non",
            "camera" to "Caméra", "front" to "Avant", "back" to "Arrière", "ext" to "Externe",
            "r_level" to "Niveau matériel", "r_manual" to "Réglages manuels du capteur", "r_raw" to "RAW (DNG)",
            "r_ten" to "10 bits (HDR)", "r_multi" to "Caméra multiple (logique)", "r_phys" to "Objectifs physiques",
            "r_iso" to "Plage ISO", "r_shut" to "Plage de vitesse (ns)", "r_focal" to "Focales (mm)",
            "r_focus" to "Mise au point minimale (dioptries)", "r_vid" to "Vidéo max", "r_fps" to "Images/s max"
        ),
        "en" to mapOf(
            "switch" to "Switch camera", "lang" to "Language: English", "report" to "Device report",
            "auto" to "Everything auto", "manExp" to "Manual exposure", "manFocus" to "Manual focus",
            "iso" to "ISO", "shutter" to "Shutter", "focus" to "Focus",
            "noperm" to "Camera permission denied. Enable it in the phone settings.",
            "nocam" to "No camera found", "err" to "Camera error", "yes" to "Yes", "no" to "No",
            "camera" to "Camera", "front" to "Front", "back" to "Rear", "ext" to "External",
            "r_level" to "Hardware level", "r_manual" to "Manual sensor controls", "r_raw" to "RAW (DNG)",
            "r_ten" to "10-bit (HDR)", "r_multi" to "Multi-camera (logical)", "r_phys" to "Physical lenses",
            "r_iso" to "ISO range", "r_shut" to "Shutter range (ns)", "r_focal" to "Focal lengths (mm)",
            "r_focus" to "Minimum focus (diopters)", "r_vid" to "Max video", "r_fps" to "Max fps"
        ),
        "sw" to mapOf(
            "switch" to "Badilisha kamera", "lang" to "Lugha: Kiswahili", "report" to "Ripoti ya kifaa",
            "auto" to "Kila kitu kiotomatiki", "manExp" to "Mwangaza wa mkono", "manFocus" to "Fokasi ya mkono",
            "iso" to "ISO", "shutter" to "Kasi", "focus" to "Fokasi",
            "noperm" to "Ruhusa ya kamera imekataliwa. Iwashe kwenye mipangilio ya simu.",
            "nocam" to "Hakuna kamera iliyopatikana", "err" to "Hitilafu ya kamera", "yes" to "Ndiyo", "no" to "Hapana",
            "camera" to "Kamera", "front" to "Mbele", "back" to "Nyuma", "ext" to "Nje",
            "r_level" to "Kiwango cha vifaa", "r_manual" to "Udhibiti wa mkono wa kihisi", "r_raw" to "RAW (DNG)",
            "r_ten" to "Biti 10 (HDR)", "r_multi" to "Kamera nyingi (kimantiki)", "r_phys" to "Lenzi halisi",
            "r_iso" to "Masafa ya ISO", "r_shut" to "Masafa ya kasi (ns)", "r_focal" to "Urefu wa fokasi (mm)",
            "r_focus" to "Fokasi ya chini (diopta)", "r_vid" to "Video ya juu", "r_fps" to "Fremu/s za juu"
        )
    )
    private var lang = "fr"
    private fun t(k: String): String = S[lang]?.get(k) ?: S["fr"]?.get(k) ?: k

    private lateinit var cm: CameraManager
    private var ids: List<String> = emptyList()
    private var idx = 0
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var builder: CaptureRequest.Builder? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null

    private lateinit var root: FrameLayout
    private lateinit var tex: TextureView
    private lateinit var info: TextView
    private lateinit var btnSwitch: Button
    private lateinit var btnLang: Button
    private lateinit var btnReport: Button
    private lateinit var btnAuto: Button
    private lateinit var cbExp: CheckBox
    private lateinit var cbFocus: CheckBox
    private lateinit var sbIso: SeekBar
    private lateinit var sbShut: SeekBar
    private lateinit var sbFocus: SeekBar
    private lateinit var tvIso: TextView
    private lateinit var tvShut: TextView
    private lateinit var tvFocus: TextView
    private lateinit var tvReport: TextView

    private var previewSize = Size(1280, 720)
    private var isoRange: Range<Int>? = null
    private var expRange: Range<Long>? = null
    private var minFocus = 0f
    private var manualOk = false
    private var afVideoOk = false
    private var infoBase = ""

    private class Seek(val f: () -> Unit) : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { f() }
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {}
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun label(): TextView = TextView(this).apply {
        setTextColor(Color.parseColor("#D4D4D8")); textSize = 13f; setPadding(0, dp(8), 0, dp(2))
    }

    private fun button(): Button = Button(this).apply { isAllCaps = false; textSize = 13f }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        lang = getSharedPreferences("cinecam", MODE_PRIVATE).getString("lang", "fr") ?: "fr"
        cm = getSystemService(CAMERA_SERVICE) as CameraManager
        buildUi()
        try {
            ids = cm.cameraIdList.filter { id ->
                val caps = cm.getCameraCharacteristics(id).get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
                caps != null && caps.contains(0)
            }
        } catch (e: Exception) {
            ids = emptyList()
        }
        applyTexts()
    }

    private fun buildUi() {
        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        tex = TextureView(this)
        root.addView(tex, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        tex.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) { openCurrent() }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean = true
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }

        info = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 12f
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(Color.parseColor("#66000000"))
        }
        root.addView(info, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(12))
            setBackgroundColor(Color.parseColor("#B3000000"))
        }
        btnSwitch = button(); btnLang = button(); btnReport = button(); btnAuto = button()
        cbExp = CheckBox(this).apply { setTextColor(Color.WHITE) }
        cbFocus = CheckBox(this).apply { setTextColor(Color.WHITE) }
        tvIso = label(); tvShut = label(); tvFocus = label()
        sbIso = SeekBar(this).apply { max = 1000; progress = 300 }
        sbShut = SeekBar(this).apply { max = 1000; progress = 500 }
        sbFocus = SeekBar(this).apply { max = 1000; progress = 0 }
        tvReport = TextView(this).apply {
            setTextColor(Color.parseColor("#E5E7EB")); textSize = 12f
            setPadding(0, dp(8), 0, 0); visibility = View.GONE
        }

        panel.addView(btnSwitch); panel.addView(btnLang)
        panel.addView(cbExp); panel.addView(tvIso); panel.addView(sbIso); panel.addView(tvShut); panel.addView(sbShut)
        panel.addView(cbFocus); panel.addView(tvFocus); panel.addView(sbFocus)
        panel.addView(btnAuto); panel.addView(btnReport); panel.addView(tvReport)

        val scroll = ScrollView(this)
        scroll.addView(panel)
        root.addView(scroll, FrameLayout.LayoutParams(dp(300), -1, Gravity.END))
        setContentView(root)

        btnSwitch.setOnClickListener {
            if (ids.size > 1) {
                idx = (idx + 1) % ids.size
                cbExp.isChecked = false; cbFocus.isChecked = false
                openCurrent()
            }
        }
        btnLang.setOnClickListener {
            lang = when (lang) { "fr" -> "en"; "en" -> "sw"; else -> "fr" }
            getSharedPreferences("cinecam", MODE_PRIVATE).edit().putString("lang", lang).apply()
            applyTexts()
        }
        btnReport.setOnClickListener {
            tvReport.visibility = if (tvReport.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        btnAuto.setOnClickListener {
            cbExp.isChecked = false; cbFocus.isChecked = false
            updateSliders(); applyControls()
        }
        cbExp.setOnCheckedChangeListener { _, _ -> updateSliders(); applyControls() }
        cbFocus.setOnCheckedChangeListener { _, _ -> updateSliders(); applyControls() }
        val seek = Seek { updateLabels(); applyControls() }
        sbIso.setOnSeekBarChangeListener(seek)
        sbShut.setOnSeekBarChangeListener(seek)
        sbFocus.setOnSeekBarChangeListener(seek)
    }

    private fun applyTexts() {
        btnSwitch.text = t("switch"); btnLang.text = t("lang"); btnReport.text = t("report"); btnAuto.text = t("auto")
        cbExp.text = t("manExp"); cbFocus.text = t("manFocus")
        if (ids.isEmpty()) info.text = t("nocam")
        else {
            refreshInfo()
            tvReport.text = report(ids[idx])
        }
        updateLabels()
    }

    private fun updateSliders() {
        val e = if (cbExp.visibility == View.VISIBLE && cbExp.isChecked) View.VISIBLE else View.GONE
        tvIso.visibility = e; sbIso.visibility = e; tvShut.visibility = e; sbShut.visibility = e
        val f = if (cbFocus.visibility == View.VISIBLE && cbFocus.isChecked) View.VISIBLE else View.GONE
        tvFocus.visibility = f; sbFocus.visibility = f
        updateLabels()
    }

    private fun isoValue(): Int {
        val r = isoRange ?: return 100
        return (r.lower + (r.upper - r.lower) * sbIso.progress / 1000.0).toInt().coerceIn(r.lower, r.upper)
    }

    private fun shutterNs(): Long {
        val r = expRange ?: return 10_000_000L
        val lo = r.lower.toDouble().coerceAtLeast(1.0)
        val hi = minOf(r.upper, 100_000_000L).toDouble().coerceAtLeast(lo)
        return Math.exp(Math.log(lo) + (Math.log(hi) - Math.log(lo)) * sbShut.progress / 1000.0).toLong()
    }

    private fun updateLabels() {
        tvIso.text = t("iso") + " : " + isoValue()
        tvShut.text = t("shutter") + " : 1/" + Math.round(1e9 / shutterNs())
        tvFocus.text = t("focus") + " : " + "%.2f".format(minFocus * sbFocus.progress / 1000f) + " D"
    }

    override fun onResume() {
        super.onResume()
        thread = HandlerThread("cam").also { it.start() }
        handler = Handler(thread!!.looper)
        if (tex.isAvailable) openCurrent()
    }

    override fun onPause() {
        closeCamera()
        thread?.quitSafely()
        thread = null
        handler = null
        super.onPause()
    }

    private fun openCurrent() {
        if (handler == null) return
        if (ids.isEmpty()) { info.text = t("nocam"); return }
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 1)
            return
        }
        openCamera(ids[idx])
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == 1 && res.isNotEmpty() && res[0] == PackageManager.PERMISSION_GRANTED) openCurrent()
        else info.text = t("noperm")
    }

    private val stateCb = object : CameraDevice.StateCallback() {
        override fun onOpened(d: CameraDevice) { device = d; startPreview() }
        override fun onDisconnected(d: CameraDevice) { d.close(); device = null }
        override fun onError(d: CameraDevice, error: Int) {
            d.close(); device = null
            runOnUiThread { info.text = t("err") + " (" + error + ")" }
        }
    }

    @SuppressLint("MissingPermission")
    private fun openCamera(id: String) {
        closeCamera()
        try {
            val c = cm.getCameraCharacteristics(id)
            readCaps(c)
            pickPreview(c)
            cm.openCamera(id, stateCb, handler)
        } catch (e: Exception) {
            info.text = t("err") + " : " + e.message
        }
    }

    private fun closeCamera() {
        try { session?.close() } catch (e: Exception) {}
        session = null
        try { device?.close() } catch (e: Exception) {}
        device = null
        builder = null
    }

    private fun readCaps(c: CameraCharacteristics) {
        val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: IntArray(0)
        isoRange = c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
        expRange = c.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
        minFocus = c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        manualOk = caps.contains(1) && isoRange != null && expRange != null
        afVideoOk = c.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES)
            ?.contains(CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_VIDEO) == true
        cbExp.visibility = if (manualOk) View.VISIBLE else View.GONE
        cbFocus.visibility = if (minFocus > 0f) View.VISIBLE else View.GONE
        updateSliders()
        tvReport.text = report(c)
    }

    private fun pickPreview(c: CameraCharacteristics) {
        val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP) ?: return
        val sizes = map.getOutputSizes(SurfaceTexture::class.java) ?: return
        previewSize = sizes.filter { it.width <= 1920 && it.height <= 1080 && it.width * 9 == it.height * 16 }
            .maxByOrNull { it.width.toLong() * it.height }
            ?: sizes.filter { it.width <= 1920 && it.height <= 1080 }.maxByOrNull { it.width.toLong() * it.height }
            ?: sizes[0]
        val facing = when (c.get(CameraCharacteristics.LENS_FACING)) {
            CameraCharacteristics.LENS_FACING_FRONT -> t("front")
            CameraCharacteristics.LENS_FACING_BACK -> t("back")
            else -> t("ext")
        }
        infoBase = facing + " · id " + ids[idx] + " · " + previewSize.width + "×" + previewSize.height
        refreshInfo()
        fit()
    }

    private fun refreshInfo() { if (infoBase.isNotEmpty()) info.text = infoBase }

    private fun fit() {
        val rw = root.width
        val rh = root.height
        if (rw == 0 || rh == 0) return
        val ar = previewSize.width.toFloat() / previewSize.height
        var w = rw
        var h = (rw / ar).toInt()
        if (h > rh) { h = rh; w = (rh * ar).toInt() }
        tex.layoutParams = FrameLayout.LayoutParams(w, h, Gravity.CENTER)
    }

    @Suppress("DEPRECATION")
    private fun startPreview() {
        val d = device ?: return
        val st = tex.surfaceTexture ?: return
        st.setDefaultBufferSize(previewSize.width, previewSize.height)
        val surface = Surface(st)
        try {
            val b = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
            b.addTarget(surface)
            builder = b
            d.createCaptureSession(listOf(surface), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    session = s
                    runOnUiThread { applyControls() }
                }
                override fun onConfigureFailed(s: CameraCaptureSession) {
                    runOnUiThread { info.text = t("err") }
                }
            }, handler)
        } catch (e: Exception) {
            runOnUiThread { info.text = t("err") + " : " + e.message }
        }
    }

    private fun applyControls() {
        val b = builder ?: return
        val s = session ?: return
        if (cbExp.visibility == View.VISIBLE && cbExp.isChecked) {
            b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_OFF)
            b.set(CaptureRequest.SENSOR_SENSITIVITY, isoValue())
            b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, shutterNs())
        } else {
            b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON)
        }
        if (cbFocus.visibility == View.VISIBLE && cbFocus.isChecked) {
            b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_OFF)
            b.set(CaptureRequest.LENS_FOCUS_DISTANCE, minFocus * sbFocus.progress / 1000f)
        } else if (afVideoOk) {
            b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_VIDEO)
        }
        try {
            s.setRepeatingRequest(b.build(), null, handler)
        } catch (e: Exception) {
        }
    }

    private fun report(id: String): String = report(cm.getCameraCharacteristics(id))

    private fun report(c: CameraCharacteristics): String {
        val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: IntArray(0)
        fun yn(b: Boolean) = if (b) t("yes") else t("no")
        val lvl = when (c.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)) {
            0 -> "LIMITED"; 1 -> "FULL"; 2 -> "LEGACY"; 3 -> "LEVEL_3"; 4 -> "EXTERNAL"; else -> "?"
        }
        val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
        val raw = map?.getOutputSizes(ImageFormat.RAW_SENSOR)
        val rawTxt = if (raw != null && raw.isNotEmpty()) {
            val m = raw.maxByOrNull { it.width.toLong() * it.height }
            yn(true) + (if (m != null) " (" + m.width + "×" + m.height + ")" else "")
        } else yn(false)
        val vid = map?.getOutputSizes(MediaRecorder::class.java)?.maxByOrNull { it.width.toLong() * it.height }
        val focal = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)
            ?.joinToString(", ") { "%.1f".format(it) } ?: "?"
        val phys = if (Build.VERSION.SDK_INT >= 28) c.physicalCameraIds.joinToString(", ") else ""
        val fps = c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.maxOfOrNull { it.upper }
        val ten = Build.VERSION.SDK_INT >= 33 && caps.contains(18)
        val iso = c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
        val exp = c.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
        val sb = StringBuilder()
        sb.append(t("r_level")).append(" : ").append(lvl).append('\n')
        sb.append(t("r_manual")).append(" : ").append(yn(caps.contains(1))).append('\n')
        sb.append(t("r_raw")).append(" : ").append(rawTxt).append('\n')
        sb.append(t("r_ten")).append(" : ").append(yn(ten)).append('\n')
        sb.append(t("r_multi")).append(" : ").append(yn(caps.contains(11))).append('\n')
        if (phys.isNotEmpty()) sb.append(t("r_phys")).append(" : ").append(phys).append('\n')
        if (iso != null) sb.append(t("r_iso")).append(" : ").append(iso.lower).append(" – ").append(iso.upper).append('\n')
        if (exp != null) sb.append(t("r_shut")).append(" : ").append(exp.lower).append(" – ").append(exp.upper).append('\n')
        sb.append(t("r_focal")).append(" : ").append(focal).append('\n')
        sb.append(t("r_focus")).append(" : ").append(c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f).append('\n')
        if (vid != null) sb.append(t("r_vid")).append(" : ").append(vid.width).append("×").append(vid.height).append('\n')
        if (fps != null) sb.append(t("r_fps")).append(" : ").append(fps)
        return sb.toString()
    }
}
